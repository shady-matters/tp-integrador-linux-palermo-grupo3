#!/bin/bash

# Carpeta temporal donde se guardarán los tar.gz
TMP_DIR="/root/backups_tmp"
mkdir -p "$TMP_DIR"

# Archivo para almacenar el contenido de /proc/partitions
cat /proc/partitions > /root/particion

# Lista de directorios a comprimir (excluyendo /proc para evitar freeze)
DIRS=("/root" "/etc" "/opt" "/www_dir" "/backup_dir")

echo "Comenzando la compresión individual..."

for dir in "${DIRS[@]}"; do
    base=$(basename "$dir")
    tar -czf "$TMP_DIR/${base}.tar.gz" "$dir"
    echo "Comprimido: $dir -> $TMP_DIR/${base}.tar.gz"
done

echo "Copiando archivo particion..."
cp /root/particion "$TMP_DIR"

echo "Evitar comprimir /proc por posible freeze del sistema."

echo "Comenzando compresión y split de /var..."

# Comprimir /var en un archivo temporal
tar -czf /root/var.tar.gz /var

# Dividir el archivo tar.gz en partes de 100MB para facilitar subida
split -b 100M /root/var.tar.gz "$TMP_DIR/var_part_"

echo "Split de /var realizado en $TMP_DIR/var_part_*"

echo "Backup finalizado. Archivos guardados en $TMP_DIR"
