#!/bin/bash

# Función para mostrar ayuda
mostrar_ayuda() {
    echo "Uso: $0 -o <origen> -d <destino> [-help]"
    echo " -o Origen: directorio a respaldar"
    echo " -d Destino: directorio donde se guardará el backup"
    echo " -help Muestra esta ayuda"
}

# Validar argumentos
if [[ "$1" == "-help" || "$#" -eq 0 ]]; then
    mostrar_ayuda
    exit 0
fi

while getopts ":o:d:" opt; do
  case $opt in
    o) ORIGEN="$OPTARG" ;;
    d) DESTINO="$OPTARG" ;;
    \?) echo "Opción inválida -$OPTARG" >&2; mostrar_ayuda; exit 1 ;;
    :) echo "La opción -$OPTARG requiere un argumento." >&2; mostrar_ayuda; exit 1 ;;
  esac
done

# Validar que existan origen y destino
if [[ -z "$ORIGEN" || -z "$DESTINO" ]]; then
    echo "Error: Debe especificar origen y destino"
    mostrar_ayuda
    exit 1
fi

# Validar que origen y destino estén montados (existentes y accesibles)
if ! mountpoint -q "$ORIGEN"; then
    echo "Error: El directorio origen $ORIGEN no está montado o no existe"
    exit 1
fi

if ! mountpoint -q "$DESTINO"; then
    echo "Error: El directorio destino $DESTINO no está montado o no existe"
    exit 1
fi

# Obtener fecha actual en formato YYYMMDD
FECHA=$(date +%Y%m%d)

# Nombre base del directorio origen sin '/'
BASE_ORIGEN=$(basename "$ORIGEN")

# Nombre archivo backup
ARCHIVO="$DESTINO/${BASE_ORIGEN}_bkp_${FECHA}.tar.gz"

# Ejecutar el backup con tar
tar -czf "$ARCHIVO" -C "$(dirname "$ORIGEN")" "$BASE_ORIGEN"

# Confirmar éxito
if [[ $? -eq 0 ]]; then
    echo "Backup creado correctamente: $ARCHIVO"
else
    echo "Error al crear backup"
fi
